// EmailJS configuration
window.onload = function() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('date').min = today;
    emailjs.init(""); //enter your server
};

// Email service configuration
const EMAIL_CONFIG = {
    serviceID: "",   //enetr you ID
    templateID: "", //enter your templete ID
    fromName: "CardioCare",
    senderEmail: "##@gmail.com" //enter your mail
};