function resetForm() {
    document.getElementById('bookingForm').reset();
    isOTPVerified = false;
    document.querySelector('.submit-btn').disabled = true;
    document.querySelector('.otp-form').style.display = 'none';
    
    const errorElements = document.querySelectorAll('.error');
    errorElements.forEach(element => {
        element.textContent = '';
        element.style.color = '#ff0000';
    });
    
    otpInputs.forEach(input => {
        input.value = '';
    });
    
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('date').min = today;
}

function handleFormSubmit(event) {
    event.preventDefault();
    
    if (validateForm()) {
        alert('Appointment booked successfully!');
        const alertDialog = document.querySelector('.alert');
        if (alertDialog) {
            alertDialog.addEventListener('close', resetForm);
        } else {
            setTimeout(resetForm, 100);
        }
        return true;
    }
    return false;
}