function filterName() {
    const nameInput = document.getElementById('name');
    nameInput.value = nameInput.value.replace(/[^A-Za-z\s]/g, '');
}

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validateMobile(mobile) {
    const mobileRegex = /^[0-9]{10}$/;
    return mobileRegex.test(mobile);
}

function validateForm() {
    const name = document.getElementById('name').value.trim();
    const mobile = document.getElementById('mobile').value.trim();
    let isValid = true;
    
    document.getElementById('nameError').textContent = '';
    document.getElementById('mobileError').textContent = '';
    
    if (name.length < 3) {
        document.getElementById('nameError').textContent = 'Name must be at least 3 characters long';
        isValid = false;
    }
    
    if (!validateMobile(mobile)) {
        document.getElementById('mobileError').textContent = 'Please enter a valid 10-digit mobile number';
        isValid = false;
    }
    
    return isValid && isOTPVerified;
}