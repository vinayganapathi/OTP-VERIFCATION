let generatedOTP = '';
let isOTPVerified = false;

const otpInputs = document.querySelectorAll('.otp-input');

function setupOTPInputs() {
    otpInputs.forEach((input, index) => {
        input.addEventListener('keyup', (e) => {
            if (e.key !== "Backspace" && input.value) {
                if (index < otpInputs.length - 1) {
                    otpInputs[index + 1].focus();
                }
                checkOTPCompletion();
            }
            if (e.key === "Backspace" && !input.value && index > 0) {
                otpInputs[index - 1].focus();
            }
            if (input.value.length > 1) {
                input.value = input.value.slice(0, 1);
            }
        });
    });
}

function checkOTPCompletion() {
    const verifyButton = document.querySelector('.verify-btn');
    let isComplete = true;
    otpInputs.forEach(input => {
        if (!input.value) isComplete = false;
    });
    verifyButton.disabled = !isComplete;
}

function generateOTP() {
    return Math.floor(1000 + Math.random() * 9000).toString();
}

function sendOTP() {
    const email = document.getElementById('email').value;
    
    if (!validateEmail(email)) {
        document.getElementById('emailError').textContent = 'Please enter a valid email address';
        return;
    }

    generatedOTP = generateOTP();
    
    const templateParams = {
        from_name: EMAIL_CONFIG.fromName,
        OTP: generatedOTP,
        message: "Please use this OTP to verify your email address.",
        reply_to: email
    };

    emailjs.send(EMAIL_CONFIG.serviceID, EMAIL_CONFIG.templateID, templateParams)
        .then(() => {
            document.querySelector('.otp-form').style.display = 'block';
            document.getElementById('emailError').textContent = 'OTP sent successfully!';
            document.getElementById('emailError').style.color = 'green';
        })
        .catch(() => {
            document.getElementById('emailError').textContent = 'Failed to send OTP. Please try again.';
            document.getElementById('emailError').style.color = 'red';
        });
}

function verifyOTP() {
    let enteredOTP = '';
    otpInputs.forEach(input => {
        enteredOTP += input.value;
    });
    
    const otpError = document.getElementById('otpError');
    const verifyButton = document.querySelector('.verify-btn');
    
    if (enteredOTP === generatedOTP) {
        isOTPVerified = true;
        otpError.textContent = 'Email verified successfully!';
        otpError.style.color = 'green';
        document.querySelector('.submit-btn').disabled = false;
    } else {
        verifyButton.classList.add('error-shake');
        setTimeout(() => {
            verifyButton.classList.remove('error-shake');
        }, 500);
        otpError.textContent = 'Invalid OTP. Please try again.';
        otpError.style.color = 'red';
        isOTPVerified = false;
        document.querySelector('.submit-btn').disabled = true;
    }
}

// Initialize OTP input handling
setupOTPInputs();